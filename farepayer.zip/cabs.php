<!DOCTYPE html>
<html lang="en"><head>
	<meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
    <meta name="viewport" content="width=device-width, initial-scale = 1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Best Holiday Pacakges, Fligts, Hotels at Lowest Prices- Farepayer.com</title>
    <meta name="description" content="Farepayer.com is one of the leading Travel Companies in India, based in Delhi. We offer a consistent service and multiple resources to satisfy your every travel related desire. " />

	<!--font google-->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css">
	

	
	
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
	<link rel="stylesheet" href="css/style.css">
    <!--flight slider links-->
   
     <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript">
        window.alert = function(){};
        var defaultCSS = document.getElementById('bootstrap-css');
        function changeCSS(css){
            if(css) $('head > link').filter(':first').replaceWith('<link rel="stylesheet" href="'+ css +'" type="text/css" />'); 
            else $('head > link').filter(':first').replaceWith(defaultCSS); 
        }
        $( document ).ready(function() {
          var iframe_height = parseInt($('html').height()); 
          window.parent.postMessage( iframe_height, 'https://bootsnipp.com');
        });
    </script>
    <!--flight links-->

<!--slider links-->
<link rel="stylesheet" type="text/css" href="css/stylesslider.css" />
<link rel="stylesheet" type="text/css" href="css/animateslider.css" />
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet prefetch" href="css/owl.carousel.min.css">

<!--slider links end-->

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
 <style>
  /* Make the image fully responsive */
  .carousel-inner img {
      width: 100%;
      height: 100%;
  }
	  ul
{
    list-style-type: none;
}
  </style>
   
    <!--style end-->
	</head>
	<body>


		<div id="fh5co-wrapper">
		<div id="fh5co-page">
	
	
<!-- Start:header-top -->
 
    <?php include 'header.php'; ?>
        
 <!-- end header-top -->
            
 <!-- START Banner -->      
	
            <div class="fh5co-hero">
			<div class="fh5co-overlay"></div>
			<div class="fh5co-cover">
	

		
	<div class="fh5co-hero">
			<div class="fh5co-overlay "></div>
			<div class="fh5co-cover " data-stellar-background-ratio="0.5" style="background-image: url(images/cover_bg_4.jpg);">
				<div class="desc">
					<div class="container">
						<div class="row">
							<div class="col-sm-5 col-md-5">
								<!-- <a href="index.html" id="main-logo">Travel</a> -->
								<div class="tabulation animate-box">

						

								</div>
							</div>
							<div class="desc2 animate-box">
								<div class="col-md-12">
									
									<h2>Exclusive Limited Time Offer</h2>
									<h3>Fly to Hong Kong via Los Angeles, USA</h3>
									<span class="price">Rs. 5999/-</span>
									<!-- <p><a class="btn btn-primary btn-lg" href="#">Get Started</a></p> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
	
	

			
			
			
				
				</div>
			</div>

		</div>
		</div>
	
	<!-- end Banner -->
	

        
        

<!-- Tour Packages start-->
<div class="container-fluid">
						<div class="row">
						<div class="container">
						<div class="col-md-12 tBackground">
						
						<b>Cab Booking </b>
						<br>
						<img src="images/service/line.jpg" alt="">
						</div>	
	

				
					<div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-1.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>New York</h3>
								<span><h5>3 nights + Flight 5*Hotel</h5></span>
								<span class="price">45,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="	fa fa-paper-plane"></i></h4></a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-2.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>Philippines</h3>
								<span><h5>4 nights + Flight 5*Hotel</h5></span>
								<span class="price">50,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="fa fa-paper-plane"></i></h4></a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-3.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>Hongkong</h3>
								<span><h5>2 nights + Flight 4*Hotel</h5></span>
								<span class="price">60,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="fa fa-paper-plane"></i></h4></a>
							</div>
						</div>
					</div>
					
			
                            
                       <div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-1.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>New York</h3>
								<span><h5>3 nights + Flight 5*Hotel</h5></span>
								<span class="price">45,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="fa fa-paper-plane"></i></h4></a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-2.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>Philippines</h3>
								<span><h5>4 nights + Flight 5*Hotel</h5></span>
								<span class="price">50,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="fa fa-paper-plane"></i></h4></a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-3.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>Hongkong</h3>
								<span><h5>2 nights + Flight 4*Hotel</h5></span>
								<span class="price">60,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="fa fa-paper-plane"></i></h4></a>
							</div>
						</div>
					</div>
					     
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            </div>
		</div>
</div>
<!-- Tour Packages start-->	


<!--footer start-->	
		
        <?php include 'footer.php'; ?>

<!--footer end-->



	<!-- jQuery -->
    <script type="text/javascript" src="engine1/wowslider.js"></script>
	<script type="text/javascript" src="engine1/script.js"></script>
	<!-- End WOWSlider.com BODY section -->

	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	<!-- START sticky footer --><script src="../demoscript.js"></script><!-- END sticky footer -->

  <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-65003908-1', 'auto');
      ga('send', 'pageview');

    </script>

</body>
</html>


