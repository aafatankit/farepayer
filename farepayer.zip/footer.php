<!--footer start-->	
		
		<footer>
			<div id="footer">
				<div class="container">
					<div class="row row-bottom-padded-md">
						
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Company</h3>
							<ul>
								<li><a href="#">About Us</a></li>
								<li><a href="#">International Tours</a></li>
								<li><a href="#">Domestic Tours</a></li>
								<li><a href="#">Testimonial</a></li>
								
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Help</h3>
							<ul>
								<li><a href="#">Contact</a></li>
								<li><a href="#">Careers</a></li>
								<li><a href="#">Terms & Conditions</a></li>
								<li><a href="#">Privacy and Policy</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Important links</h3>
							<ul>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								
							</ul>
						</div>
						
					
					
				
							<div class="col-md-5 col-sm-2 col-xs-12 text-center">
						<h3 style="color: white;">Connect</h3>
						<br>
				<p class="fh5co-social-icons text-right">	
					<a href="https://twitter.com/farepayertravel"><i class="fa fa-twitter" style="font-size:28px;"></i></a>	
					<a href="https://www.facebook.com/farepayer/"><i class="fa fa-facebook-official" style="font-size:28px;"></i></a>
					<a href="https://www.instagram.com/farepayertourtravel/"><i class="fa fa-instagram" style="font-size:28px;"></i></a>
					<a href="https://www.linkedin.com/company/farepayer"><i class="fa fa-linkedin-square" style="font-size:28px;"></i></a>
					<a href="https://plus.google.com/108143226066444546526"><i class="fa fa-google-plus-square" style="font-size:28px;"></i></a>
					<a href="#"><i class="fa fa-youtube-play" style="font-size:28px;"></i></a>
					<a href="#"><img src="images/we Accept/iato.png" alt=""></a>
								</p>
					
						</div>
						
			
							<div class="col-md-12 text-center" style="margin-top: 20px;
    border-top: white solid 1px;
"><br><p></p>
							<div class="row">
								<div class="col-md-6">
							<p>Copyright © 2018 Farepayer. All Rights Reserved.Made with <i class="fa fa-heart"></i> by <a href="#" target="_blank">Farepayer</a></p>
							
							
							
							</div>
								<div class="col-md-6">	
						
							
						<ul class="Visa">
						<li><h4 style="color: white;">We Accept</h4></li>
						<li><img src="images/we Accept/payicon01.png" alt=""></li>
						<li><img src="images/we Accept/payicon02.png" alt=""></li>
						<li><img src="images/we Accept/payicon03.png" alt=""></li>
						<li><img src="images/we Accept/payicon04.png" alt=""></li>
						<li><img src="images/we Accept/payicon05.png" alt=""></li>
						<li><img src="images/we Accept/payicon06.png" alt=""></li>
						</ul>
						 
									
									
									
								</div>
							
							
							</div>
							
							
						</div>
					</div>
				</div>
			
		</footer>

<!--footer end-->