<!-- Start:header-top -->
	
            <div class="bg-primary">
            <div class="container">
                <div class="row">
        
                    <span class="col-md-3 text-white text-left"></span>
                    <span class="col-md-5"></span>
                    <span class="col-md-4 text-white text-right" style="font-size: 12px; margin-bottom: 3px; ">
                        <span class="float-right"><i class="fa fa-envelope"></i> support@farepayer.com</span>
                        <span class="float-right"><i class="fa fa-phone-square"></i> 011-45661507 &nbsp;&nbsp;</span>
                        
<!--
                        <span class="row">
                            <span class="col text-left"><i class="fa fa-envelope"></i>011-45661507</span>
                            <span class="col text-right"><i class="fa fa-envelope"></i> support@farepayer.com</span>
                        </span>
-->
                    </span>
                </div>
            </div>
        </div>
            <nav class="navbar navbar-expand-md navbar-light bg-white sticky-top">
                <div class="container">
                    <a href="#" class="navbar-brand"><img src="images/logo.png"></a>
                    <button class="navbar-toggler" data-toggle="collapse" data-target="#navbaraId">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div id="navbaraId" class="collapse navbar-collapse">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                <a href="TourPackages.php" class="nav-link"><i class="fa fa-suitcase"></i> Tour Packages</a>
                            </li>
                            <li class="nav-item">
                                <a href="flight.php" class="nav-link"><i class="fa fa-send"></i> Flights</a>
                            </li>
                            <li class="nav-item">
                                <a href="Hotels.php" class="nav-link"><i class="fa fa-hotel"></i> Hotels</a>
                            </li>
                            <li class="nav-item">
                                <a href="cabs.php" class="nav-link"><i class="fa fa-taxi"></i> Cabs</a>
                            </li>
                            <li class="nav-item">
                                <a href="Offers.php" class="nav-link"><i class="fa fa-twitch"></i> Offers</a>
                            </li>
                            <li class="nav-item">
                                <a href="#" class="nav-link"><i class="fa fa-user"></i> Login</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        

	<!-- end:header-top -->