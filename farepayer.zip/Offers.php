<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
    <meta name="viewport" content="width=device-width, initial-scale = 1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Best Holiday Pacakges, Fligts, Hotels at Lowest Prices- Farepayer.com</title>
    <meta name="description" content="Farepayer.com is one of the leading Travel Companies in India, based in Delhi. We offer a consistent service and multiple resources to satisfy your every travel related desire. " />


	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<script type="text/javascript" src="engine1/jquery.js"></script>
	<link rel="stylesheet" href="css/style.css">

<!--slider links-->
<link rel="stylesheet" type="text/css" href="css/stylesslider.css" />
<link rel="stylesheet" type="text/css" href="css/animateslider.css" />
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" />
<link rel="stylesheet prefetch" href="css/owl.carousel.min.css">

<!--slider links end-->

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>

	<body>


<div class="row">
<div class=
	
	
	
	
</div>

				
				
		<div class="container mt-40">
            <h3 class="text-center">Hover Effect Style : Demo - 10</h3>
            <div class="row mt-30">
                <div class="col-md-4 col-sm-6">
                    <div class="box10">
                        <img src="images/25.jpg" alt="">
                        <div class="box-content">
                            <h3 class="title">Williamson</h3>
                            <ul class="icon">
                                <li><a href="#" class="fa fa-search"></a></li>
                                <li><a href="#" class="fa fa-link"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="box10">
                        <img src="images/26.jpg" alt="">
                        <div class="box-content">
                            <h3 class="title">Kristiana</h3>
                            <ul class="icon">
                                <li><a href="#" class="fa fa-search"></a></li>
                                <li><a href="#" class="fa fa-link"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="box10">
                        <img src="images/27.jpg" alt="">
                        <div class="box-content">
                            <h3 class="title">Kristiana</h3>
                            <ul class="icon">
                                <li><a href="#" class="fa fa-search"></a></li>
                                <li><a href="#" class="fa fa-link"></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>		
				
				
				
					
<!--slider Start-->		
					
<div class="modal fade" id="myModal1" role="dialog">
<div class="modal-dialog">
<!-- Modal content-->
<div class="modal-content">
<div class="modal-body">
<img src="images/portfolio/La Conceptz Infra Solutions.png" class="img-responsive" alt="" /></div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">X</button>
</div></div></div></div>
<div class="container2">
    <div class="photobanner">
        <img class="first" src="images/slider/0.jpg" alt="">
        <img src="images/slider/0 [1].jpg" alt=""/>
        <img src="images/slider/0 [2].jpg" alt=""/>
       <img src="images/slider/0 [4].jpg" alt=""/>
        <img src="images/slider/0.jpg" alt=""/>
        <img src="images/slider/0.jpg" alt="">
        <img src="images/slider/raj.jpg" alt=""/>
        <img src="images/slider/ra.jpg" alt=""/>
         <img src="images/slider/0.jpg" alt=""/>
         <img src="images/slider/ra.jpg" alt=""/>
           <img src="images/slider/0 [1].jpg" alt=""/>
    </div>
</div>


<!--slider end-->

<!--Start Service-->	
				


<!--end Service-->
<br>
<p></p>

 

<!-- Most Popular Destination start-->
<div class="container-fluid">
						<div class="row sBackground">
						<div class="container">
						<div class="col-md-12 tBackground">
						
						<b>Most Popular Destination</b>
						<br>
						<img src="images/service/line.jpg" alt="">
						</div>	
	

				
					<div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-1.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>New York</h3>
								<span><h5>3 nights + Flight 5*Hotel</h5></span>
								<span class="price">45,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="fa fa-map-marker"></i></h4></a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-2.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>Philippines</h3>
								<span><h5>4 nights + Flight 5*Hotel</h5></span>
								<span class="price">50,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="fa fa-map-marker"></i></h4></a>
							</div>
						</div>
					</div>
					<div class="col-md-4 col-sm-6 fh5co-tours animate-box" data-animate-effect="fadeIn">
						<div href="#"><img src="images/place-3.jpg" alt="" class="img-responsive">
							<div class="desc">
								<span></span>
								<h3>Hongkong</h3>
								<span><h5>2 nights + Flight 4*Hotel</h5></span>
								<span class="price">60,000</span>
								<a class="btn btn-primary btn-outline" href="#"><h4>Book Now <i class="fa fa-map-marker"></i></h4></a>
							</div>
						</div>
					</div>
					<div class="col-md-12 text-center animate-box">
						<p><a class="btn btn-primary btn-outline btn-lg" href="#" style="margin-top: 30px;">
						<b>See All Offers </b><i class="fa fa-map-marker"></i></a></p>
					</div>
			</div>
		</div>
</div>
<!-- Most Popular Destination End-->



	
	







<!--footer start-->	
		
		<?php include 'footer.php'; ?>

<!--footer end-->



	<!-- jQuery -->
    <script type="text/javascript" src="engine1/wowslider.js"></script>
	<script type="text/javascript" src="engine1/script.js"></script>
	<!-- End WOWSlider.com BODY section -->

	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	<!-- START sticky footer --><script src="../demoscript.js"></script><!-- END sticky footer -->

  <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-65003908-1', 'auto');
      ga('send', 'pageview');

    </script>

</body>
</html>


